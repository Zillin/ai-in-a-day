#!/usr/bin/env python
# coding: utf-8

# # Plan real-world action using counterfactual example analysis and causal analysis
# 
# This notebooks is an adaptation of the [corresponding notebook in the `responsible-ai-toolbox` repository](https://github.com/microsoft/responsible-ai-toolbox/blob/main/notebooks/responsibleaidashboard/responsibleaidashboard-diabetes-decision-making.ipynb), modified to work with the Responsible AI components in AzureML.
# 
# We will use the Responsible AI components to assess a regression model trained on diabetes progression data. Next, we will walk through the API calls necessary to create a widget with model analysis insights, then undertake a visual analysis of the model.
# 
# First, we need to specify the version of the RAI components which are available in the workspace. This was specified when the components were uploaded, and will have defaulted to '1':

# In[ ]:


version_string = '1'


# We also need to give the name of the compute cluster we want to use in AzureML. Later in this notebook, we will create it if it does not already exist:

# In[ ]:


compute_name = "cpucluster"


# Finally, we need to specify a version for the data and components we will create while running this notebook. This should be unique for the workspace, but the specific value doesn't matter:

# In[ ]:


rai_diabetes_decision_making_example_version_string = '8'


# ## Accessing the data
# 
# First, we need to obtain the dataset and upload it to our AzureML workspace:

# In[ ]:


import sklearn.datasets
import pandas as pd

from sklearn.model_selection import train_test_split


# In[ ]:


data = sklearn.datasets.load_diabetes()
target_feature = 'y'
continuous_features = data.feature_names
data_df = pd.DataFrame(data.data, columns=data.feature_names)
data_df[target_feature] = data.target


# Now, split the data into training and test sets:

# In[ ]:


data_train, data_test = train_test_split(data_df, test_size=0.2, random_state=7)


# Write to parquet files:

# In[ ]:


train_filename = "diabetes_decision_train.parquet"
test_filename = "diabetes_decision_test.parquet"

data_train.to_parquet(train_filename, index=False)
data_test.to_parquet(test_filename, index=False)


# We are going to create two Datasets in AzureML, one for the train and one for the test datasets. The first step is to create an `MLClient` to perform the upload. The method we use assumes that there is a `config.json` file (downloadable from the Azure or AzureML portals) present in the same directory as this notebook file:

# In[ ]:


from azure.ai.ml import MLClient
from azure.identity import DefaultAzureCredential
ml_client = MLClient.from_config(credential=DefaultAzureCredential(exclude_shared_token_cache_credential=True),
                     logging_enable=True)


# We can then define and upload the datasets:

# In[ ]:


from azure.ai.ml.entities import Data
from azure.ai.ml.constants import AssetTypes

input_train_data = "diabetes_decision_train_pq"
input_test_data = "diabetes_decision_test_pq"

train_data = Data(
    path=train_filename,
    type=AssetTypes.URI_FILE,
    description="RAI diabetes decision example training data",
    name=input_train_data,
    version=rai_diabetes_decision_making_example_version_string,
)
ml_client.data.create_or_update(train_data)

test_data = Data(
    path=test_filename,
    type=AssetTypes.URI_FILE,
    description="RAI diabetes decision example test data",
    name=input_test_data,
    version=rai_diabetes_decision_making_example_version_string,
)
ml_client.data.create_or_update(test_data)


# ## A model training pipeline
# 
# To simplify the model creation process, we're going to use a pipeline. This will have two stages:
# 
# 1. The actual training component
# 1. A model registration component
# 
# We have to register the model in AzureML in order for our RAI insights components to use it.
# 
# ### The Training Component
# 
# The training component is for this particular model. In this case, we are going to train a `RandomForestRegressor` on the input data and save it using MLFlow. We need command line arguments to specify the location of the input data, the location where MLFlow should write the output model, and the name of the target column in the dataset.
# 
# We start by creating a directory to hold the component source:

# In[ ]:


import os

os.makedirs('component_src', exist_ok=True)


# Next, put our training script into the directory:

# In[ ]:


get_ipython().run_cell_magic('writefile', 'component_src/diabetes_decision_training_script.py', '\nimport argparse\nimport os\nimport shutil\nimport tempfile\n\n\nfrom azureml.core import Run\n\nimport mlflow\nimport mlflow.sklearn\n\nimport pandas as pd\nfrom sklearn.ensemble import RandomForestRegressor\n\ndef parse_args():\n    # setup arg parser\n    parser = argparse.ArgumentParser()\n\n    # add arguments\n    parser.add_argument("--training_data", type=str, help="Path to training data")\n    parser.add_argument("--target_column_name", type=str, help="Name of target column")\n    parser.add_argument("--model_output", type=str, help="Path of output model")\n\n    # parse args\n    args = parser.parse_args()\n\n    # return args\n    return args\n\n\ndef main(args):\n    current_experiment = Run.get_context().experiment\n    tracking_uri = current_experiment.workspace.get_mlflow_tracking_uri()\n    print("tracking_uri: {0}".format(tracking_uri))\n    mlflow.set_tracking_uri(tracking_uri)\n    mlflow.set_experiment(current_experiment.name)\n\n    # Read in data\n    print("Reading data")\n    all_data = pd.read_parquet(args.training_data)\n\n    print("Extracting X_train, y_train")\n    print("all_data cols: {0}".format(all_data.columns))\n    y_train = all_data[args.target_column_name]\n    X_train = all_data.drop(labels=args.target_column_name, axis="columns")\n    print("X_train cols: {0}".format(X_train.columns))\n\n    print("Training model")\n    # The estimator can be changed to suit\n    model = RandomForestRegressor()\n    model.fit(X_train, y_train)\n\n    # Saving model with mlflow - leave this section unchanged\n    with tempfile.TemporaryDirectory() as td:\n        print("Saving model with MLFlow to temporary directory")\n        tmp_output_dir = os.path.join(td, "my_model_dir")\n        mlflow.sklearn.save_model(sk_model=model, path=tmp_output_dir)\n\n        print("Copying MLFlow model to output path")\n        for file_name in os.listdir(tmp_output_dir):\n            print("  Copying: ", file_name)\n            # As of Python 3.8, copytree will acquire dirs_exist_ok as\n            # an option, removing the need for listdir\n            shutil.copy2(src=os.path.join(tmp_output_dir, file_name), dst=os.path.join(args.model_output, file_name))\n\n\n# run script\nif __name__ == "__main__":\n    # add space in logs\n    print("*" * 60)\n    print("\\n\\n")\n\n    # parse args\n    args = parse_args()\n\n    # run main function\n    main(args)\n\n    # add space in logs\n    print("*" * 60)\n    print("\\n\\n")\n')


# Now that the training script is saved on our local drive, we create a YAML file to describe it as a component to AzureML. This involves defining the inputs and outputs, specifing the AzureML environment which can run the script, and telling AzureML how to invoke the training script:

# In[ ]:


from azure.ai.ml import load_component

yaml_contents = f"""
$schema: http://azureml/sdk-2-0/CommandComponent.json
name: rai_diabetes_decision_training_component
display_name: Diabetes decision training component for RAI example
version: {rai_diabetes_decision_making_example_version_string}
type: command
inputs:
  training_data:
    type: path
  target_column_name:
    type: string
outputs:
  model_output:
    type: path
code: ./component_src/
environment: azureml:AML-RAI-Environment:{version_string}
""" + r"""
command: >-
  python diabetes_decision_training_script.py
  --training_data ${{{{inputs.training_data}}}}
  --target_column_name ${{{{inputs.target_column_name}}}}
  --model_output ${{{{outputs.model_output}}}}
"""

yaml_filename = "RAIDiabetesDecisionTrainingComponent.yaml"

with open(yaml_filename, 'w') as f:
    f.write(yaml_contents.format(yaml_contents))
    
train_component_definition = load_component(
    path=yaml_filename
)

ml_client.components.create_or_update(train_component_definition)


# ### Running a training pipeline
# 
# The component to register the model is part of the suite of RAI components, so we do not have to define it here. As such, we are now ready to run the training pipeline itself.
# 
# We start by ensuring that the compute cluster named above exists:

# In[ ]:


from azure.ai.ml.entities import AmlCompute

all_compute_names = [x.name for x in ml_client.compute.list()]

if compute_name in all_compute_names:
    print(f"Found existing compute: {compute_name}")
else:
    my_compute = AmlCompute(
        name=compute_name,
        size="Standard_DS2_v2",
        min_instances=0,
        max_instances=4,
        idle_time_before_scale_down=3600
    )
    ml_client.compute.begin_create_or_update(my_compute)
    print("Initiated compute creation")


# We continue by defining the name under which we want to register the model:

# In[ ]:


import time

model_name_suffix = int(time.time())
model_name = 'rai_diabetes_decision_model'


# Next, we define the pipeline using objects from the AzureML SDKv2. As mentioned above, there are two component jobs: one to train the model, and one to register it:

# In[ ]:


from azure.ai.ml import dsl, Input

register_component = ml_client.components.get(
    name="register_model", version=version_string
)
train_model_component = ml_client.components.get(
    name="rai_diabetes_decision_training_component",
    version=rai_diabetes_decision_making_example_version_string
)
diabetes_train_pq = Input(
    type="uri_file",
    path=f"{input_train_data}:{rai_diabetes_decision_making_example_version_string}",
    mode="download"
)
diabetes_test_pq = Input(
    type="uri_file",
    path=f"{input_test_data}:{rai_diabetes_decision_making_example_version_string}",
    mode="download"
)

@dsl.pipeline(
    compute=compute_name,
    description="Register Model for RAI Diabetes Decision Making example",
    experiment_name=f"RAI_Diabetes_Decision_Example_Model_Training_{model_name_suffix}",
)
def my_training_pipeline(target_column_name, training_data):
    trained_model = train_component_definition(
        target_column_name=target_column_name,
        training_data=training_data
    )
    trained_model.set_limits(timeout=120)

    _ = register_component(
        model_input_path=trained_model.outputs.model_output,
        model_base_name=model_name,
        model_name_suffix=model_name_suffix,
    )

    return {}

model_registration_pipeline_job = my_training_pipeline(target_feature, diabetes_train_pq)


# With the pipeline definition created, we can submit it to AzureML. We define a helper function to do the submission, which waits for the submitted job to complete:

# In[ ]:


from azure.ai.ml.entities import PipelineJob

def submit_and_wait(ml_client, pipeline_job) -> PipelineJob:
    created_job = ml_client.jobs.create_or_update(pipeline_job)
    assert created_job is not None

    while created_job.status not in ['Completed', 'Failed', 'Canceled', 'NotResponding']:
        time.sleep(30)
        created_job = ml_client.jobs.get(created_job.name)
        print("Latest status : {0}".format(created_job.status))
    assert created_job.status == 'Completed'
    return created_job

# This is the actual submission
training_job = submit_and_wait(ml_client, model_registration_pipeline_job)


# ##  Creating the RAI Insights
# 
# We have a registered model, and can now run a pipeline to create the RAI insights. First off, compute the name of the model we registered:

# In[ ]:


expected_model_id = f'{model_name}_{model_name_suffix}:1'


# Now, we create the RAI pipeline itself. There are four 'component stages' in this pipeline:
# 
# 1. Fetch the model
# 1. Construct an empty `RAIInsights` object
# 1. Run the RAI tool components
# 1. Gather the tool outputs into a single `RAIInsights` object
# 1. (Optional) Generate a score card in pdf format summarizing model performance, and key aspects from the rai tool components
# 
# We start by loading the RAI component definitions for use in our pipeline:

# In[ ]:


fetch_model_component = ml_client.components.get(
    name='fetch_registered_model', version=version_string
)

rai_constructor_component = ml_client.components.get(
    name="rai_insights_constructor", version=version_string
)

rai_causal_component = ml_client.components.get(
    name="rai_insights_causal", version=version_string
)

rai_counterfactual_component = ml_client.components.get(
    name="rai_insights_counterfactual", version=version_string
)

rai_gather_component = ml_client.components.get(
    name="rai_insights_gather", version=version_string
)

rai_scorecard_component = ml_client.components.get(
    name="rai_score_card", version=version_string
)


# ## Score card generation config
# For score card generation, we need some additional configuration in a separate json file. Here we configure the following model performance metrics for reporting:
# - mean absolute error
# - mean squared error

# In[ ]:


import json

score_card_config_dict = {
    "Model": {
        "ModelName": "Diabetes disease progression measure",
        "ModelType": "Regression",
        "ModelSummary": "This model provides a quantitative measure of disease progression one year after baseline"
    },
    "Metrics" :{
        "mean_absolute_error": {
            "threshold": "<=5"
        },
        "mean_squared_error": {}
    }
}

score_card_config_filename = "rai_diabetes_decision_score_card_config.json"

with open(score_card_config_filename, 'w') as f:
    json.dump(score_card_config_dict, f)


# Now the pipeline itself. This fetches the registered model, creates an empty `RAIInsights` object, adds the analyses, and then gathers everything into the final `RAIInsights` output. Where complex objects need to be passed (such as a list of treatment feature names), they must be encoded as JSON strings.
# 
# Note that the timeout for the counterfactual generation is longer, since this is a comparatively slow process.

# In[ ]:


score_card_config_path = Input(
    type="uri_file",
    path=score_card_config_filename,
    mode="download"
)

treatment_feature_names = json.dumps(["bmi", "bp", "s2"])
desired_range = json.dumps([50, 120])


@dsl.pipeline(
        compute=compute_name,
        description="Example RAI computation on diabetes decision making data",
        experiment_name=f"RAI_Diabetes_Decision_Example_RAIInsights_Computation_{model_name_suffix}",
    )
def rai_decision_pipeline(
        target_column_name,
        train_data,
        test_data,
        score_card_config_path
    ):
        # Fetch the model
        fetch_job = fetch_model_component(
            model_id=expected_model_id
        )
        
        # Initiate the RAIInsights
        create_rai_job = rai_constructor_component(
            title="RAI Dashboard Example",
            task_type="regression",
            model_info_path=fetch_job.outputs.model_info_output_path,
            train_dataset=train_data,
            test_dataset=test_data,
            target_column_name=target_column_name,
        )
        create_rai_job.set_limits(timeout=120)

        # Add causal analysis
        causal_job = rai_causal_component(
            rai_insights_dashboard=create_rai_job.outputs.rai_insights_dashboard,
            treatment_features=treatment_feature_names
        )
        causal_job.set_limits(timeout=120)
        
        # Add counterfactual analysis
        counterfactual_job = rai_counterfactual_component(
            rai_insights_dashboard=create_rai_job.outputs.rai_insights_dashboard,
            total_cfs=20,
            desired_range=desired_range,
        )
        counterfactual_job.set_limits(timeout=600)

        # Combine everything
        rai_gather_job = rai_gather_component(
            constructor=create_rai_job.outputs.rai_insights_dashboard,
            insight_2=causal_job.outputs.causal,
            insight_3=counterfactual_job.outputs.counterfactual,
        )
        rai_gather_job.set_limits(timeout=120)

        rai_gather_job.outputs.dashboard.mode = "upload"
        rai_gather_job.outputs.ux_json.mode = "upload"
        
        # Generate score card in pdf format for a summary report on model performance,
        # and observe distrbution of error between prediction vs ground truth.
        rai_scorecard_job = rai_scorecard_component(
            dashboard=rai_gather_job.outputs.dashboard,
            pdf_generation_config=score_card_config_path
        )

        return {
            "dashboard": rai_gather_job.outputs.dashboard,
            "ux_json": rai_gather_job.outputs.ux_json,
            "scorecard": rai_scorecard_job.outputs.scorecard
        }


# Next, we define the pipeline object itself, and ensure that the outputs will be available for download:

# In[ ]:


import uuid
from azure.ai.ml import Output

# Pipeline to construct the RAI Insights
insights_pipeline_job = rai_decision_pipeline(
    target_column_name=target_feature,
    train_data=diabetes_train_pq,
    test_data=diabetes_test_pq,
    score_card_config_path=score_card_config_path
)

# Workaround to enable the download
rand_path = str(uuid.uuid4())
insights_pipeline_job.outputs.dashboard = Output(
    path=f"azureml://datastores/workspaceblobstore/paths/{rand_path}/dashboard/",
    mode="upload",
    type="uri_folder",
)
insights_pipeline_job.outputs.ux_json = Output(
    path=f"azureml://datastores/workspaceblobstore/paths/{rand_path}/ux_json/",
    mode="upload",
    type="uri_folder",
)
insights_pipeline_job.outputs.scorecard = Output(
    path=f"azureml://datastores/workspaceblobstore/paths/{rand_path}/scorecard/",
    mode="upload",
    type="uri_folder",
)


# And submit the pipeline to AzureML for execution:

# In[ ]:


insights_job = submit_and_wait(ml_client, insights_pipeline_job)


# The dashboard should appear in the AzureML portal in the registered model view. The following cell computes the expected URI:

# In[ ]:


sub_id = ml_client._operation_scope.subscription_id
rg_name = ml_client._operation_scope.resource_group_name
ws_name = ml_client.workspace_name

expected_uri = f"https://ml.azure.com/model/{expected_model_id}/model_analysis?wsid=/subscriptions/{sub_id}/resourcegroups/{rg_name}/workspaces/{ws_name}"

print(f"Please visit {expected_uri} to see your analysis")


# Following the link should bring you to a page which looks similar to:
# ![image.png](attachment:image.png)

# This page lists all of the RAI dashboards computed for this model. To view one, click on the appropriate entry in the 'Name' column.

# ## Downloading the Scorecard PDF
# 
# We can download the scorecard PDF from our pipeline as follows:

# In[ ]:


target_directory = "."

ml_client.jobs.download(
    insights_job.name, download_path=target_directory, output_name="scorecard"
)


# ### Constructing the Pipeline in YAML
# 
# It is possible to define the pipeline in a YAML file, and submit it using the AzureML extensions for the Azure MLI. We can create the required YAML file as follows:

# In[ ]:


yaml_contents = f"""
$schema: https://azuremlschemas.azureedge.net/latest/pipelineJob.schema.json
experiment_name: RAI_Diabetes_Decision_Example_YAML_{rai_diabetes_decision_making_example_version_string}
type: pipeline

inputs:
  target_column_name: {target_feature}
  my_training_data:
    type: uri_file
    path: azureml:{input_train_data}:{rai_diabetes_decision_making_example_version_string}
    mode: download
  my_test_data:
    type: uri_file
    path: azureml:{input_train_data}:{rai_diabetes_decision_making_example_version_string}
    mode: download

settings:
  default_datastore: azureml:workspaceblobstore
  default_compute: azureml:{compute_name}
  continue_on_step_failure: false

jobs:
  fetch_model_job:
    type: command
    component: azureml:fetch_registered_model:{version_string}
    inputs:
      model_id: {expected_model_id}

  create_rai_job:
    type: command
    component: azureml:rai_insights_constructor:{version_string}
    inputs:
      title: RAI Diabetes Decision Analysis from YAML
      task_type: regression
      model_info_path: ${{{{parent.jobs.fetch_model_job.outputs.model_info_output_path}}}}
      train_dataset: ${{{{parent.inputs.my_training_data}}}}
      test_dataset: ${{{{parent.inputs.my_test_data}}}}
      target_column_name: ${{{{parent.inputs.target_column_name}}}}
      
  causal_01:
    type: command
    component: azureml:rai_insights_causal:{version_string}
    inputs:
      rai_insights_dashboard: ${{{{parent.jobs.create_rai_job.outputs.rai_insights_dashboard}}}}
      treatment_features: '["bmi", "bp", "s2"]'

  counterfactual_01:
    type: command
    component: azureml:rai_insights_counterfactual:{version_string}
    inputs:
      rai_insights_dashboard: ${{{{parent.jobs.create_rai_job.outputs.rai_insights_dashboard}}}}
      total_CFs: 20
      desired_range: '[50, 120]'

  gather_01:
    type: command
    component: azureml:rai_insights_gather:{version_string}
    inputs:
      constructor: ${{{{parent.jobs.create_rai_job.outputs.rai_insights_dashboard}}}}
      insight_2: ${{{{parent.jobs.counterfactual_01.outputs.counterfactual}}}}
      insight_4: ${{{{parent.jobs.causal_01.outputs.causal}}}}
  
  scorecard_01:
    type: command
    component: azureml:rai_score_card:{version_string}
    inputs:
      dashboard: ${{{{parent.jobs.gather_01.outputs.dashboard}}}}
      pdf_generation_config:
        type: uri_file
        path: {score_card_config_filename}
"""

yaml_pipeline_filename = "rai_diabetes_decision_example.yaml"

with open(yaml_pipeline_filename, 'w') as f:
    f.write(yaml_contents)


# The created file can then be submitted using the Azure CLI:

# In[ ]:


cmd_line = ['az', 'ml', 'job', 'create',
            '--resource-group', rg_name,
            '--workspace', ws_name,
            '--file', yaml_pipeline_filename]

import subprocess

try:
    cmd = subprocess.run(cmd_line, check=True, shell=True, capture_output=True)
except subprocess.CalledProcessError as cpe:
    print(f"Error invoking: {cpe.args}")
    print(cpe.stdout)
    print(cpe.stderr)
    raise
else:
    print("Azure CLI submission completed")


# ## Take Real-World Action
# 
# ### What-If Counterfactuals Analysis
# 
# Let's imagine that the diabetes progression scores predicted by the model are used to determine medical insurance rates (note that how to perform an analysis will change based on the real-world scenario under consideration). Suppose that if the score is greater than 120, there is a higher rate. Patient 43's model score of 271.1 (note that this can vary slightly due to random number generation) results in this increased rate, and they want to know how they should change their health to get a lower rate prediction from the model (leading to lower insurance price).
# 
# The What-If counterfactuals component shows how slightly different feature values affect model predictions. This can be used to solve Patient 43's problem.
# 
# ![image-2.png](attachment:image-2.png)

# What can Patient 43 do to create the desired change? The top ranked features bar plot shows that `bmi` and `s5` are the best to perturb to bring the model score within 120:
# 
# ![image.png](attachment:image.png)

# ### Causal Analysis
# 
# Now suppose that a doctor wishes to know how to reduce the progression of diabetes in her patients. This can be explored in the Causal Inference component of the Responsible AI Toolbox.
# 
# In the "Aggregate causal effects" tab, it is possible to see how perturbing features causes lower disease progression. It appears that increasing s2 (LDL) by one unit, would increase diabetes progression by around 684 units (again, exact values can vary due to random number effects):
# 
# ![image.png](attachment:image.png)

# In[ ]:




